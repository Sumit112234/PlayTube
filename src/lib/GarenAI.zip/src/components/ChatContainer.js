// src/components/ChatContainer.js
import React, { useState } from 'react';
import Message from './Message';
import InputArea from './InputArea';

const ChatContainer = () => {
    const [messages, setMessages] = useState([]);

    const handleUserInput = (userText) => {
        // Add user message to state
        console.log(messages);
        const updatedMessage = [...messages, { text: userText, isUser: true }];

    // Replace with logic to fetch bot response (e.g., from an API)
    const botResponse = 'Hello! I am your ChatGPT clone.';
    const updatedMessagesWithBotResponse = [...updatedMessage, { text: botResponse, isUser: false }];

    // Update the state with the combined messages
    setMessages(updatedMessagesWithBotResponse);
    };

    return (
        <div >
        <div className="chat-container">
            <div className="messages-container">

            {messages.map((message, index) => (
                <Message key={index} text={message.text} isUser={message.isUser} />
            ))}
            </div>
            <div className="">
            </div>
        </div>
        <InputArea onUserInput={handleUserInput} />
        </div>
    );
};

export default ChatContainer;
