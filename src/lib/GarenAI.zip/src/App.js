// src/App.js
import React from 'react';
// import './style.css'; // Import your external CSS file
import ChatContainer from './components/ChatContainer';
import Header from './components/Header';
import Navbar from './components/Navbar';
import { BrowserRouter } from 'react-router-dom';
import { Routes,Route } from 'react-router-dom';
import Home from './components/Home';
import About from './components/About';
import Details from './components/DetailsPage';


function App() {
    return (
<>
<BrowserRouter>
        <div className="">
        <Header/>
<Routes>
           <Route  path='/' element = {<Home/>}/>
           <Route path='/About' element = {<About/>}/>
           <Route path='/AskFromGaren' element={<ChatContainer />}/>
           <Route path='/detail/:id' element={<Details />}/>

</Routes>
        </div>
</BrowserRouter>
            
</>
    );
}

export default App;
