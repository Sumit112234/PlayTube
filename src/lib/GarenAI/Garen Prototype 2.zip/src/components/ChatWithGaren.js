import React from 'react'

const ChatWithGaren = () => {
  return (
    <div className='text-white bg-red-500'>ChatWithGaren</div>
  )
}

export default ChatWithGaren