import { useState } from 'react'

export default function DetailsPage() {
    const [tabs, setTabs] = useState("Details")
    return (
        <div className='h-[100vh] w-full bg-white opacity-80'>
            <h1 className='bg-red-500 text-center font-bold text-3xl font-serif mt-4'>Tulsi</h1>

        </div>
    )
}